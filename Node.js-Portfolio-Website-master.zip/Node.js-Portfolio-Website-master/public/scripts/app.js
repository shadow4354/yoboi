(function(){
    console.log("App Started..");
})();